from abc import ABC , abstractmethod
class ShowData:
    @abstractmethod
    def showData(self):
        pass
