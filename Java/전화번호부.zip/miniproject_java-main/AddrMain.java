package miniproject1;

public class AddrMain {

	public static void main(String[] args) {
		
		Addr addr = new Addr("최호준", "010-0000-0000", "choi@gmail.com","서울","친구");
		
		addr.printInfo();
		
		System.out.println("==============================");
		System.out.println("그룹 정보 변경");
		System.out.println("==============================");
		
		addr.setGroup("가족");
		addr.printInfo();

	}

}